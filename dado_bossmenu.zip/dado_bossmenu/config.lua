Config = {}

-- Príkaz a klávesa na otvorenie menu
Config.OpenCommand = 'bossmenu'
Config.OpenKey = 'F7'

-- Za akou vzdialenosťou môžeš prijať hráča (v metroch)
Config.HireDistance = 3.0

-- Odkiaľ sa vkladá / kam sa vyberá (suma sa berie z peňazí pri sebe)
Config.DepositFrom = 'cash'   -- 'cash' alebo 'bank'
Config.WithdrawTo = 'cash'    -- 'cash' alebo 'bank'

-- Minimálna a maximálna suma na jeden prevod
Config.MinAmount = 1
Config.MaxAmount = 10000000

-- Hodnosť s ktorou sa hráč prijme do práce (štandardne 0 = prvá)
Config.HireGrade = 0

-- Job pre vyhodenie z práce
Config.UnemployedJob = 'unemployed'

-- Manuálny boss (ak nemáš v job_grades nastavený stĺpec isboss)
-- Príklad: Config.BossGrades = { police = 3, ambulance = 2 }
Config.BossGrades = {}

-- Môže si boss meniť vlastnú hodnosť? (false = nie, kvôli ochrane)
Config.CanChangeOwnGrade = false
