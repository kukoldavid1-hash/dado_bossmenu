fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'dado_bossmenu'
description 'Boss menu pre ESX Legacy + ox_lib'
author 'dado'
version '1.0.0'

shared_scripts {
    '@ox_lib/init.lua',
    '@es_extended/imports.lua',
    'config.lua',
}

client_scripts {
    'client/main.lua',
}

server_scripts {
    'server/main.lua',
}

dependencies {
    'es_extended',
    'ox_lib',
}
