local gradesCache = {}

local function GetGrades(jobName)
    if gradesCache[jobName] then
        return gradesCache[jobName]
    end

    local grades

    local ok, rows = pcall(function()
        return MySQL.query.await('SELECT grade, name, label, isboss FROM job_grades WHERE job_name = ?', { jobName })
    end)

    if ok and rows and #rows > 0 then
        grades = {}
        for _, row in ipairs(rows) do
            grades[tonumber(row.grade)] = {
                label = row.label,
                name = row.name,
                isboss = row.isboss == true or tonumber(row.isboss) == 1,
            }
        end
    end

    if not grades and ESX.GetJobs then
        local okJobs, jobs = pcall(ESX.GetJobs)
        local job = okJobs and jobs and jobs[jobName]
        if job and job.grades then
            grades = {}
            for grade, data in pairs(job.grades) do
                grades[tonumber(grade)] = {
                    label = data.label or tostring(grade),
                    name = data.name,
                    isboss = data.isboss == true or tonumber(data.isboss) == 1,
                }
            end
        end
    end

    if not grades then
        grades = {}
        for _, xTarget in ipairs(ESX.GetExtendedPlayers()) do
            local job = xTarget.getJob()
            if job.name == jobName and not grades[job.grade] then
                grades[job.grade] = {
                    label = job.grade_label or ('Úroveň ' .. job.grade),
                    name = job.grade_name,
                    isboss = job.isboss == true,
                }
            end
        end
    end

    gradesCache[jobName] = grades
    return grades
end

local function GetMaxGrade(grades)
    local max = 0
    for grade in pairs(grades) do
        if grade > max then max = grade end
    end
    return max
end

local function IsBoss(xPlayer)
    local job = xPlayer.getJob()
    if not job then return false end

    local override = Config.BossGrades[job.name]
    if override ~= nil then
        return override == job.grade
    end

    if job.isboss == true then return true end
    if job.grade_name == 'boss' then return true end

    local grades = GetGrades(job.name)
    local data = grades[job.grade]
    return data ~= nil and data.isboss == true
end

local function GetSocietyAccount(jobName)
    local account
    TriggerEvent('esx_addonaccount:getAccount', 'society_' .. jobName, function(acc)
        account = acc
    end)
    return account
end

local function CountBosses(jobName)
    local count = 0
    for _, xTarget in ipairs(ESX.GetExtendedPlayers()) do
        local job = xTarget.getJob()
        if job.name == jobName and (job.isboss == true or job.grade_name == 'boss') then
            count = count + 1
        end
    end
    return count
end

local function ValidateAmount(amount)
    amount = math.floor(tonumber(amount) or 0)
    if amount < Config.MinAmount then return nil end
    if amount > Config.MaxAmount then return nil end
    return amount
end

lib.callback.register('dado_bossmenu:getInfo', function(source)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then return nil end

    local job = xPlayer.getJob()
    if not IsBoss(xPlayer) then
        return { allowed = false }
    end

    local account = GetSocietyAccount(job.name)

    return {
        allowed = true,
        jobLabel = job.label,
        jobName = job.name,
        gradeLabel = job.grade_label,
        money = account and account.money or 0,
        hasAccount = account ~= nil,
        depositFrom = Config.DepositFrom,
        withdrawTo = Config.WithdrawTo,
    }
end)

lib.callback.register('dado_bossmenu:getEmployees', function(source)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer or not IsBoss(xPlayer) then return nil end

    local jobName = xPlayer.job.name
    local grades = GetGrades(jobName)

    local employees = {}
    for _, xTarget in ipairs(ESX.GetExtendedPlayers()) do
        local job = xTarget.getJob()
        if job.name == jobName then
            employees[#employees + 1] = {
                id = xTarget.source,
                name = (xTarget.getName and xTarget.getName() or GetPlayerName(xTarget.source)) or 'Neznámy',
                grade = job.grade,
                gradeLabel = job.grade_label or ('Úroveň ' .. job.grade),
                isYou = xTarget.source == source,
                canChange = not (xTarget.source == source and not Config.CanChangeOwnGrade),
            }
        end
    end

    table.sort(employees, function(a, b)
        return a.grade > b.grade
    end)

    return {
        employees = employees,
        maxGrade = GetMaxGrade(grades),
        grades = grades,
    }
end)

lib.callback.register('dado_bossmenu:setGrade', function(source, targetId, newGrade)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer or not IsBoss(xPlayer) then
        return false, 'Nemáš oprávnenie na túto akciu.'
    end

    targetId = tonumber(targetId)
    newGrade = tonumber(newGrade)

    if not targetId or not newGrade or newGrade % 1 ~= 0 then
        return false, 'Neplatné údaje.'
    end

    local xTarget = ESX.GetPlayerFromId(targetId)
    if not xTarget then
        return false, 'Hráč už nie je na serveri.'
    end

    if targetId == source and not Config.CanChangeOwnGrade then
        return false, 'Sám si nemôžeš meniť hodnosť.'
    end

    if xTarget.getJob().name ~= xPlayer.job.name then
        return false, 'Hráč nie je v tvojej práci.'
    end

    local grades = GetGrades(xPlayer.job.name)
    if next(grades) ~= nil and not grades[newGrade] then
        return false, 'Táto hodnosť neexistuje.'
    end

    if newGrade < 0 or newGrade > GetMaxGrade(grades) then
        return false, 'Neplatná hodnosť.'
    end

    local targetJob = xTarget.getJob()
    if targetJob.isboss == true and newGrade ~= targetJob.grade then
        local grades2 = GetGrades(xPlayer.job.name)
        local newIsBoss = grades2[newGrade] and grades2[newGrade].isboss
        if not newIsBoss and CountBosses(xPlayer.job.name) <= 1 then
            return false, 'V práci musí zostať aspoň jeden boss.'
        end
    end

    xTarget.setJob(xPlayer.job.name, newGrade)

    local label = grades[newGrade] and grades[newGrade].label or ('Úroveň ' .. newGrade)
    TriggerClientEvent('ox_lib:notify', source, { type = 'success', description = ('Povýšil/znížil si hráča %s na hodnosť %s.'):format(xTarget.getName(), label) })
    TriggerClientEvent('ox_lib:notify', targetId, { type = 'info', description = ('Tvoja hodnosť bola zmenená na: %s'):format(label) })

    return true, label
end)

lib.callback.register('dado_bossmenu:hire', function(source, targetId)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer or not IsBoss(xPlayer) then
        return false, 'Nemáš oprávnenie na túto akciu.'
    end

    targetId = tonumber(targetId)
    if not targetId then return false, 'Neplatný hráč.' end

    local xTarget = ESX.GetPlayerFromId(targetId)
    if not xTarget then return false, 'Hráč už nie je na serveri.' end
    if targetId == source then return false, 'Seba nemôžeš prijať.' end

    local ok, tooFar = pcall(function()
        local srcPed = GetPlayerPed(source)
        local tgtPed = GetPlayerPed(targetId)
        if srcPed == 0 or tgtPed == 0 then return false end
        local dist = #(GetEntityCoords(srcPed) - GetEntityCoords(tgtPed))
        return dist <= Config.HireDistance
    end)

    if ok and tooFar == false then
        return false, 'Hráč je príliš ďaleko.'
    end

    local grades = GetGrades(xPlayer.job.name)
    if next(grades) ~= nil and not grades[Config.HireGrade] then
        return false, 'Nastav Config.HireGrade na existujúcu hodnosť.'
    end

    xTarget.setJob(xPlayer.job.name, Config.HireGrade)

    TriggerClientEvent('ox_lib:notify', source, { type = 'success', description = ('Prijal si hráča %s.'):format(xTarget.getName()) })
    TriggerClientEvent('ox_lib:notify', targetId, { type = 'success', description = ('Bol/a si prijatý/á do práce: %s'):format(xPlayer.job.label) })

    return true
end)

lib.callback.register('dado_bossmenu:fire', function(source, targetId)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer or not IsBoss(xPlayer) then
        return false, 'Nemáš oprávnenie na túto akciu.'
    end

    targetId = tonumber(targetId)
    if not targetId then return false, 'Neplatný hráč.' end
    if targetId == source then return false, 'Seba nemôžeš vyhodiť.' end

    local xTarget = ESX.GetPlayerFromId(targetId)
    if not xTarget then return false, 'Hráč už nie je na serveri.' end
    if xTarget.getJob().name ~= xPlayer.job.name then return false, 'Hráč nie je v tvojej práci.' end

    local name = xTarget.getName()
    xTarget.setJob(Config.UnemployedJob, 0)

    TriggerClientEvent('ox_lib:notify', source, { type = 'success', description = ('Vyhodil si hráča %s.'):format(name) })
    TriggerClientEvent('ox_lib:notify', targetId, { type = 'error', description = ('Bol/a si vyhodený/á z práce: %s'):format(xPlayer.job.label) })

    return true
end)

lib.callback.register('dado_bossmenu:deposit', function(source, amount)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer or not IsBoss(xPlayer) then
        return false, 'Nemáš oprávnenie na túto akciu.'
    end

    amount = ValidateAmount(amount)
    if not amount then return false, 'Neplatná suma.' end

    local account = GetSocietyAccount(xPlayer.job.name)
    if not account then return false, 'Firemný účet neexistuje (skontroluj esx_addonaccount).' end

    local hasMoney = Config.DepositFrom == 'bank' and xPlayer.getAccount('bank').money >= amount or xPlayer.getMoney() >= amount
    if not hasMoney then return false, 'Nemáš dostatok peňazí.' end

    if Config.DepositFrom == 'bank' then
        xPlayer.removeAccountMoney('bank', amount, 'boss_menu_deposit')
    else
        xPlayer.removeMoney(amount, 'boss_menu_deposit')
    end

    account.addMoney(amount)

    TriggerClientEvent('ox_lib:notify', source, { type = 'success', description = ('Vložil si %s$ na firemný účet.'):format(amount) })
    return true, account.money
end)

lib.callback.register('dado_bossmenu:withdraw', function(source, amount)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer or not IsBoss(xPlayer) then
        return false, 'Nemáš oprávnenie na túto akciu.'
    end

    amount = ValidateAmount(amount)
    if not amount then return false, 'Neplatná suma.' end

    local account = GetSocietyAccount(xPlayer.job.name)
    if not account then return false, 'Firemný účet neexistuje (skontroluj esx_addonaccount).' end

    if account.money < amount then
        return false, 'Firemný účet nemá dostatok peňazí.'
    end

    account.removeMoney(amount)

    if Config.WithdrawTo == 'bank' then
        xPlayer.addAccountMoney('bank', amount, 'boss_menu_withdraw')
    else
        xPlayer.addMoney(amount, 'boss_menu_withdraw')
    end

    TriggerClientEvent('ox_lib:notify', source, { type = 'success', description = ('Vybral si %s$ z firemného účtu.'):format(amount) })
    return true, account.money
end)
