local MENU_ID = 'dado_bossmenu_main'

local function Notify(msg, nType)
    lib.notify({ type = nType or 'inform', description = msg })
end

local function AwaitCB(name, ...)
    local ok, result = pcall(lib.callback.await, name, false, ...)
    if not ok then
        Notify('Chyba komunikácie so serverom.', 'error')
        return nil
    end
    return result
end

local function GetNearbyPlayers()
    local myPed = PlayerPedId()
    local myCoords = GetEntityCoords(myPed)
    local players = {}

    for _, id in ipairs(GetActivePlayers()) do
        local ped = GetPlayerPed(id)
        if ped ~= myPed then
            local dist = #(myCoords - GetEntityCoords(ped))
            if dist <= Config.HireDistance then
                players[#players + 1] = {
                    id = GetPlayerServerId(id),
                    label = ('%s [ID: %s] - %.1fm'):format(GetPlayerName(id) or '?', GetPlayerServerId(id), dist),
                }
            end
        end
    end

    return players
end

local function OpenEmployeesMenu(info)
    local data = AwaitCB('dado_bossmenu:getEmployees')
    if not data then
        Notify('Nepodarilo sa načítať zamestnancov.', 'error')
        return
    end

    local options = {}

    if #data.employees == 0 then
        options[#options + 1] = {
            title = 'Žiadni zamestnanci online',
            disabled = true,
            icon = 'user-slash',
        }
    end

    for i, emp in ipairs(data.employees) do
        local empMenuId = ('dado_bossmenu_emp_%s'):format(i)
        local empOptions = {}

        if emp.canChange then
            if emp.grade < data.maxGrade then
                empOptions[#empOptions + 1] = {
                    title = 'Povýšiť',
                    description = ('Na hodnosť: %s'):format(data.grades[emp.grade + 1] and data.grades[emp.grade + 1].label or ('Úroveň ' .. (emp.grade + 1))),
                    icon = 'arrow-up',
                    onSelect = function()
                        local ok = AwaitCB('dado_bossmenu:setGrade', emp.id, emp.grade + 1)
                        if ok then OpenEmployeesMenu(info) end
                    end,
                }
            end

            if emp.grade > 0 then
                empOptions[#empOptions + 1] = {
                    title = 'Znížiť hodnosť',
                    description = ('Na hodnosť: %s'):format(data.grades[emp.grade - 1] and data.grades[emp.grade - 1].label or ('Úroveň ' .. (emp.grade - 1))),
                    icon = 'arrow-down',
                    onSelect = function()
                        local ok = AwaitCB('dado_bossmenu:setGrade', emp.id, emp.grade - 1)
                        if ok then OpenEmployeesMenu(info) end
                    end,
                }
            end

            if not emp.isYou then
                empOptions[#empOptions + 1] = {
                    title = 'Vyhodiť z práce',
                    description = ('%s príde o prácu'):format(emp.name),
                    icon = 'user-minus',
                    colorScheme = 'red',
                    onSelect = function()
                        local ok = AwaitCB('dado_bossmenu:fire', emp.id)
                        if ok then OpenEmployeesMenu(info) end
                    end,
                }
            end
        end

        if #empOptions == 0 then
            empOptions[1] = {
                title = 'Žiadne akcie',
                disabled = true,
                icon = 'ban',
            }
        end

        lib.registerContext({
            id = empMenuId,
            title = emp.name,
            menu = MENU_ID .. '_employees',
            options = empOptions,
        })

        options[#options + 1] = {
            title = emp.name,
            description = ('Hodnosť: %s%s'):format(emp.gradeLabel, emp.isYou and ' (ty)' or ''),
            icon = emp.isYou and 'user' or 'user-tie',
            menu = empMenuId,
        }
    end

    lib.registerContext({
        id = MENU_ID .. '_employees',
        title = ('Zamestnanci (%s)'):format(#data.employees),
        menu = MENU_ID,
        options = options,
    })

    lib.showContext(MENU_ID .. '_employees')
end

local function OpenAccountMenu(info)
    lib.registerContext({
        id = MENU_ID .. '_account',
        title = ('Firemný účet - %s$'):format(info.money),
        menu = MENU_ID,
        options = {
            {
                title = 'Vložiť peniaze',
                description = ('Zdroj: %s'):format(info.depositFrom == 'bank' and 'banka' or 'hotovosť'),
                icon = 'money-bill-transfer',
                disabled = not info.hasAccount,
                onSelect = function()
                    local input = lib.inputDialog('Vložiť peniaze', {
                        { type = 'number', label = 'Suma ($)', required = true, min = Config.MinAmount, max = Config.MaxAmount },
                    })
                    if not input or not input[1] then return end

                    local ok, msg = AwaitCB('dado_bossmenu:deposit', input[1])
                    if not ok and msg then Notify(msg, 'error') end
                    OpenAccountMenu(info)
                end,
            },
            {
                title = 'Vybrať peniaze',
                description = ('Cieľ: %s'):format(info.withdrawTo == 'bank' and 'banka' or 'hotovosť'),
                icon = 'money-bill-wave',
                disabled = not info.hasAccount,
                onSelect = function()
                    local input = lib.inputDialog('Vybrať peniaze', {
                        { type = 'number', label = 'Suma ($)', required = true, min = Config.MinAmount, max = Config.MaxAmount },
                    })
                    if not input or not input[1] then return end

                    local ok, msg = AwaitCB('dado_bossmenu:withdraw', input[1])
                    if not ok and msg then Notify(msg, 'error') end
                    OpenAccountMenu(info)
                end,
            },
            {
                title = 'Späť',
                icon = 'arrow-left',
                menu = MENU_ID,
            },
        },
    })

    lib.showContext(MENU_ID .. '_account')
end

local function OpenHireMenu(info)
    local options = {}
    local nearby = GetNearbyPlayers()

    if #nearby == 0 then
        options[#options + 1] = {
            title = ('Nikto nie je v okolí %sm'):format(Config.HireDistance),
            disabled = true,
            icon = 'user-slash',
        }
    end

    for _, player in ipairs(nearby) do
        options[#options + 1] = {
            title = player.label,
            icon = 'user-plus',
            onSelect = function()
                local ok, msg = AwaitCB('dado_bossmenu:hire', player.id)
                if ok then
                    Notify('Hráč bol prijatý do práce.', 'success')
                elseif msg then
                    Notify(msg, 'error')
                end
                OpenHireMenu(info)
            end,
        }
    end

    options[#options + 1] = {
        title = 'Späť',
        icon = 'arrow-left',
        menu = MENU_ID,
    }

    lib.registerContext({
        id = MENU_ID .. '_hire',
        title = 'Prijať hráča',
        menu = MENU_ID,
        options = options,
    })

    lib.showContext(MENU_ID .. '_hire')
end

local function OpenBossMenu()
    local info = AwaitCB('dado_bossmenu:getInfo')
    if not info then return end

    if not info.allowed then
        Notify('Na otvorenie boss menu potrebuješ hodnosť bossa.', 'error')
        return
    end

    lib.registerContext({
        id = MENU_ID,
        title = ('Boss Menu - %s'):format(info.jobLabel),
        options = {
            {
                title = 'Zamestnanci',
                description = 'Povýšenie, zníženie a vyhodenie',
                icon = 'users',
                menu = MENU_ID .. '_employees',
                onSelect = function() OpenEmployeesMenu(info) end,
            },
            {
                title = 'Firemný účet',
                description = ('Stav účtu: %s$'):format(info.money),
                icon = 'building-columns',
                menu = MENU_ID .. '_account',
                onSelect = function() OpenAccountMenu(info) end,
            },
            {
                title = 'Prijať hráča',
                description = ('Hráč musí byť v okolí %sm'):format(Config.HireDistance),
                icon = 'user-plus',
                menu = MENU_ID .. '_hire',
                onSelect = function() OpenHireMenu(info) end,
            },
        },
    })

    lib.showContext(MENU_ID)
end

RegisterCommand(Config.OpenCommand, OpenBossMenu, false)
RegisterKeyMapping(Config.OpenCommand, 'Otvoriť boss menu', 'keyboard', Config.OpenKey)

exports('OpenBossMenu', OpenBossMenu)
